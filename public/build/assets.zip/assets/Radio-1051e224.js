import{_ as r}from"./app-0e08b8e7.js";const c={};function e(n,t){return null}const o=r(c,[["render",e]]);export{o as default};
